﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mini_Personal_Verwaltungs_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btn_Signup(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string gender = "";
            if(radioButton1.Checked)
            {
                gender = radioButton1.Text;
            }
            if(radioButton2.Checked)
            {
                gender = radioButton2.Text;
            }
            string hobbies = "";
            if(checkBox1.Checked)
            {
                hobbies += checkBox1.Text;
            }
            if(checkBox2.Checked)
            {
                hobbies += checkBox2.Text;
            }
            label5.Text = $"Name = {name} \nGender = {gender} \nHobbies = {hobbies}";
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
