Heinrich-Hertz-Berufskolleg
IA222_SDM_STG 
Hausaufgabe am 22. August 2022

Personalverwaltungsapp in C# als Anfänger

Files can only be viewed with Visual Studio. 

Mini-Personal-Verwaltungs-App # Form 1
