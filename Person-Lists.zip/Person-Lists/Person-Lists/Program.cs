﻿public class Person 
{
    public string PersonName { get; set; }

    public string PersonEmail { get; set; }

    public long PersonNumber { get; set; }

    public override string ToString()
    {
        return "Name: " + PersonName + " --- E-Mail: " + PersonEmail + " --- Number: " + PersonNumber;
    }
}
public class Example
{
    public static void Main()
    {
        Console.WriteLine("IA222 | Future Software Engineers | Class of 2025");

        List<Person> persons = new List<Person>();

        persons.Add(new Person() { PersonName = "Linh Phan", PersonEmail =  "lphan@hhek.de", PersonNumber = 01638594374});
        persons.Add(new Person() { PersonName = "Abdulaziz Nabaa/Cillian", PersonEmail = "anabaa@hhek.de", PersonNumber = 01601814495});
        persons.Add(new Person() { PersonName = "Ann-Kristin Neese", PersonEmail = "aneese@hhek.de", PersonNumber = 015253204718});
        persons.Add(new Person() { PersonName = "Arne Fricke", PersonEmail = "africke@hhek.de", PersonNumber = 015146161630});
        persons.Add(new Person() { PersonName = "Dominik Hentschel", PersonEmail = "dhentschel@hhek.de", PersonNumber = 01637915406});
        persons.Add(new Person() { PersonName = "Farzad Golzari", PersonEmail = "fgolzari@hhek.de", PersonNumber = 01638320885});
        persons.Add(new Person() { PersonName = "Florian Wiesner", PersonEmail = "fwiesner@hhek.de", PersonNumber = 016098096625});
        persons.Add(new Person() { PersonName = "Gökhan Mete Topcu", PersonEmail = "gtopcu@hhek.de", PersonNumber = 015159199380});
        persons.Add(new Person() { PersonName = "Gregor Dicks", PersonEmail = "gdicks@hhek.de", PersonNumber = 015168153413});
        persons.Add(new Person() { PersonName = "Johannes Christian Häfner", PersonEmail = "jhaefner@hhek.de", PersonNumber = 01764568129});
        persons.Add(new Person() { PersonName = "Jonas Piterek", PersonEmail = "jpiterek@hhek.de", PersonNumber = 017620661212});
        persons.Add(new Person() { PersonName = "Kevin Spinler", PersonEmail = "kspinler@hhek.de", PersonNumber = 01739832089});
        persons.Add(new Person() { PersonName = "Lukas Freiherr von Ungern-Sternberg", PersonEmail = "lfreiherr@hhek.de", PersonNumber = 016092800273});
        persons.Add(new Person() { PersonName = "Noah Storck", PersonEmail = "nstorck@hhek.de", PersonNumber = 015168158025});
        persons.Add(new Person() { PersonName = "Ole Constantin Knechtel", PersonEmail = "oknechtel@hhek.de", PersonNumber = 01703685297});
        persons.Add(new Person() { PersonName = "Samir Sannat", PersonEmail = "ssannat@hhek.de", PersonNumber = 01631970938});
        persons.Add(new Person() { PersonName = "Sebastian Oehm", PersonEmail = "soehm@hhek.de", PersonNumber = 015770326913});
        persons.Add(new Person() { PersonName = "Simon Galupi", PersonEmail = "sgalupi@hhek.de", PersonNumber = 01744528480});
        persons.Add(new Person() { PersonName = "Sulaiman Sulaiman", PersonEmail = "ssulaiman@hhek.de", PersonNumber = 01788798656});
        persons.Add(new Person() { PersonName = "Tim Hüppop", PersonEmail = "thueppop@hhek.de", PersonNumber = 017623235025});
        persons.Add(new Person() { PersonName = "Timm Werres", PersonEmail = "twerres@hhek.de", PersonNumber = 017663391720});
        persons.Add(new Person() { PersonName = "Tobias Schäfer", PersonEmail = "tschaefer@hhek.de", PersonNumber = 017664820502});

        Console.WriteLine();

        foreach (Person aPerson in persons)
        {
            Console.WriteLine(aPerson);
        }
    }
}