﻿namespace Schulunterricht_Manager
{
    internal class Subject
    {
    }
}