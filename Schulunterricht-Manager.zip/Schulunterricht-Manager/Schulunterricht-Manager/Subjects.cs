﻿namespace SchoolSubjectsManager
{
    class Subjects
    {
        public int SubjectID { get; set; }
        public string SubjectName { get; set; }
        public string TeacherName { get; set; }
        public string TeacherEmail { get; set; }

        public override string ToString()
        {
            
            return "Subject_ID: " + SubjectID + "\n - The Subject: " + SubjectName + "\n - Teacher's Name: " + TeacherName + " \n - Teacher's Email: " + TeacherEmail;

        }
    }
}
