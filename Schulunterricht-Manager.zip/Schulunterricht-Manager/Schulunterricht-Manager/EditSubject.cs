﻿using SchoolSubjectsManager;

namespace Schulunterricht_Manager
{
    class EditSubject
    {
        private List<Subjects> subject = new List<Subjects>();

        public List<Subjects> Subjects()
        {
            return this.Subjects();
        }

        //Add Method
        public void AddSubject(Subjects subject)
        {
            this.subject.Add(subject);
        }


        //Remove Method
        internal void RemoveSubject(Subjects subject)
        {
            this.subject.Remove(subject);
        }


        //Find Method
        internal List<Subjects> FindSubjectID(int SubjectID)
        {
            List<Subjects> ResultFound = new List<Subjects>();

            //Search Subject by Subject_ID by using foreach()-Loop



            //and then add to ResultFound

            return FindSubjectID(SubjectID);
        }


    }
}
