﻿using SchoolSubjectsManager;
using Schulunterricht_Manager;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainList
{
    public class SchoolSubjectManager
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("IA222 | Software Engineer | HHEK");

            List<Subjects> subject = new List<Subjects>();

            subject.Add(new Subjects() { SubjectID = 1, SubjectName = "SDM - Software- & Datenmanagement", TeacherName = "Herr Stegemann", TeacherEmail = "stegemann@hhek.bonn.de" });
            subject.Add(new Subjects() { SubjectID = 2, SubjectName = "GIT - Gestaltung von IT-Dienstleistungen", TeacherName = "Herr Rösch", TeacherEmail = "roesch@hhek.bonn.de" });
            subject.Add(new Subjects() { SubjectID = 3, SubjectName = "IT-Sicherheit + Green IT", TeacherName = "Herr Müller", TeacherEmail = "mueller.h@hhek.bonn.de" });
            subject.Add(new Subjects() { SubjectID = 4, SubjectName = "EVP - Entwicklung vernetzter Prozesse", TeacherName = "Herr Müller", TeacherEmail = "mueller.h@hhek.bonn.de" });

            Console.WriteLine();
            foreach (Subjects aSubject in subject)
            {
                Console.WriteLine(aSubject);
            }


            while (true)
            {
                Console.WriteLine("\nDo you want to edit the List above? \n(Please enter one of these functions (all lowercase): 'add' - 'remove' - 'find'");
                string editList = Console.ReadLine();

                switch (editList)
                {
                    case "add":
                        Console.WriteLine("Add Something");
                        break;
                    case "remove":
                        Console.WriteLine("Remove Something");
                        break;
                    case "find":
                        Console.WriteLine("Find Something");
                        break;
                    default:
                        Console.WriteLine("False Input. Please try again!");
                        continue;
                }
                break;
            }

        }
    }
}



